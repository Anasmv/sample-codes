<?php
$data = $_POST;		
if( !empty( $data)){
	echo $client_id = ( trim( $data['client_id'] ) ); echo '<br>';
	echo $invoice_total = ( trim( $data['invoice_total'] ) ); echo '<br>';
	echo $invoice_subtotal = ( trim( $data['invoice_subtotal'] ) ); echo '<br>';
	echo $tax = ( trim( $data['tax'] ) ); echo '<br>';
	echo $amount_paid = ( trim( $data['amount_paid'] ) ); echo '<br>';
	echo $amount_due = ( trim( $data['amount_due'] ) ); echo '<br>';
	echo $notes = ( trim( $data['notes'] ) ); echo '<br>';
	echo '<br>';
}
	
if( isset( $data['data']) && !empty( $data['data'] )){
	$invoice_details=$data['data'];
    foreach ($invoice_details as $invoice_detail){
        echo $product_id = ( trim( $invoice_detail['product_id'] ) ); echo '<br>';
        echo $productName = ( trim( $invoice_detail['product_name'] ) ); echo '<br>';
		 echo $price = ( trim( $invoice_detail['price'] ) ); echo '<br>';
        echo $quantity = ( trim( $invoice_detail['quantity'] ) ); echo '<br>';
        echo $price = ( trim( $invoice_detail['total'] ) ); echo '<br>';  
    }
}